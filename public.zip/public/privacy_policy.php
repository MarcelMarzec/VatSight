<?php
require_once __DIR__ . '/partials/config.php';

$page = [
    'title'       => 'Privacy Policy — VatSight',
    'description' => 'How VatSight handles your data on vatsight.com, the contact form, the newsletter and the iOS app. No analytics, and the app collects no personal data.',
    'path'        => '/privacy_policy',
    'breadcrumbs' => [['name' => 'Privacy policy', 'path' => '/privacy_policy']],
];
require __DIR__ . '/partials/head.php';
?>
        <section class="doc-hero">
            <div class="section-inner">
                <?= breadcrumbs_html($crumbs) ?>
                <h1>Privacy Policy</h1>
                <p class="doc-updated">Last updated 4 November 2026</p>
            </div>
        </section>

        <section class="doc">
            <div class="section-inner">
                <div class="doc-card">
                    <div class="highlight-box">
                        <p><strong>Short version:</strong> The VatSight website, newsletter and iOS app are all built to collect as little personal data as possible. The website sets no tracking cookies and runs no analytics; the only third-party check is Google reCAPTCHA on the <a href="#contact-form" class="link-text">contact form</a>. The app's own code collects nothing — everything you enter stays on your device, with no accounts required, no analytics, and Mapbox's map telemetry switched off by default. Ads are optional and off by default; only if you turn them on does Google's ad SDK collect data, as described in <a href="#advertising" class="link-text">Section 9</a>.</p>
                        <p class="highlight-follow">The only personal data we ever hold is what you choose to send us: your email address if you join the <a href="#newsletter" class="link-text">VatSight newsletter</a>, and your name, email and message if you use the <a href="#contact-form" class="link-text">contact form</a>. It's used for nothing else and never shared or sold.</p>
                    </div>

                    <h2>1. Overview and Who We Are</h2>
                    <p>VatSight is a free, source-available project built around a live radar app for the <a href="https://www.vatsim.net" target="_blank" rel="noopener" class="link-text">VATSIM</a> virtual air traffic network, its website and its newsletter. This privacy policy explains what information is used, where it comes from, and how it is handled across all three:</p>
                    <ul>
                        <li>the website at <code>vatsight.com</code>, including its contact form (<a href="#website" class="link-text">Section 2</a>)</li>
                        <li>the VatSight newsletter (<a href="#newsletter" class="link-text">Section 3</a>, plus cookies in <a href="#cookies" class="link-text">Section 4</a>)</li>
                        <li>the VatSight iOS app, covered in full technical detail (Sections 5–12)</li>
                    </ul>
                    <p>VatSight is developed and maintained by Marcel Marzec, an individual based in the United Kingdom. For the purposes of UK data protection law (the UK GDPR and the Data Protection Act 2018), Marcel Marzec is the <strong>controller</strong> of any personal data described in this policy. You can reach him at <a href="mailto:contact@marcelmarzec.com" class="link-text">contact@marcelmarzec.com</a>.</p>

                    <h2 id="website">2. The Website</h2>
                    <p>The <code>vatsight.com</code> website has no user accounts, no analytics, no advertising and no tracking pixels, and it does not set any cookies of its own (the newsletter pages and the contact form's reCAPTCHA are the exceptions; see <a href="#cookies" class="link-text">Section 4</a>). Like almost every website, it still involves some technical processing:</p>
                    <ul>
                        <li><strong>Server logs.</strong> When you visit, our web hosting provider's server automatically records standard technical information: your IP address, browser user agent, the page requested, the referring page and the time. These logs are used only to keep the site running and secure, and they are deleted automatically on the hosting provider's rotation schedule.</li>
                        <li><strong>Cloudflare.</strong> The <code>vatsight.com</code> domain uses Cloudflare for DNS. Where traffic is routed through Cloudflare's network, Cloudflare processes your IP address to deliver the site and protect it from attacks. See <a href="https://www.cloudflare.com/privacypolicy/" target="_blank" rel="noopener" class="link-text">Cloudflare's privacy policy</a>.</li>
                        <li><strong>Google Fonts.</strong> The site's typefaces are loaded from Google Fonts, so your browser connects to Google's servers, which receive your IP address and user agent. See <a href="https://developers.google.com/fonts/faq/privacy" target="_blank" rel="noopener" class="link-text">Google Fonts' privacy FAQ</a>.</li>
                    </ul>
                    <p>Our lawful basis for this processing is our <strong>legitimate interests</strong> (UK GDPR Article 6(1)(f)) in running a secure, working website. We do not use this data to identify you, build profiles or track you across other sites.</p>

                    <h3 id="contact-form">The contact form</h3>
                    <p>If you send a message through the <a href="/contact" class="link-text">contact page</a>, we receive the name, email address, subject and message you enter, so we can read and reply to it. Nothing is sent unless you press <strong>Send message</strong>.</p>
                    <ul>
                        <li><strong>Formspree.</strong> The form is delivered by <a href="https://formspree.io/legal/privacy-policy/" target="_blank" rel="noopener" class="link-text">Formspree</a>, which receives what you type, your IP address and browser details, stores the submission and forwards it to our inbox. Formspree acts as our processor.</li>
                        <li><strong>Google reCAPTCHA.</strong> To keep out spam, the contact page loads Google reCAPTCHA. Google receives your IP address and some browser and device data, and sets a cookie, to judge whether you are a person. This happens only on the contact page. See <a href="https://policies.google.com/privacy" target="_blank" rel="noopener" class="link-text">Google's privacy policy</a> and <a href="https://policies.google.com/terms" target="_blank" rel="noopener" class="link-text">terms</a>.</li>
                    </ul>
                    <p>The lawful basis for handling your message is your <strong>consent</strong>, given by choosing to send it (UK GDPR Article 6(1)(a)); for reCAPTCHA it is our <strong>legitimate interest</strong> in keeping a public form free of spam (Article 6(1)(f)). We keep correspondence for as long as it is useful to have the thread, usually no more than two years, and then delete it. Ask us and we'll delete yours sooner. Your details are never added to the newsletter or passed to anyone else. If you would rather not use the form, email <a href="mailto:contact@marcelmarzec.com" class="link-text">contact@marcelmarzec.com</a> instead.</p>

                    <h2 id="newsletter">3. The Newsletter</h2>
                    <p>You can choose to join the VatSight newsletter on the <a href="/phplist/?p=subscribe&amp;id=1" class="link-text">sign-up page</a> or the home page. It is used only to email you VatSight news, release announcements and major updates. The welcome email you receive once you confirm also includes an optional invite to the VatSight TestFlight beta, where you can try upcoming versions before they're released.</p>

                    <h3>What we store</h3>
                    <div class="table-scroll">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Why</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Your email address</td>
                                    <td>To send you the newsletter</td>
                                </tr>
                                <tr>
                                    <td>Email format preference (HTML or plain text)</td>
                                    <td>To send emails in the format you prefer</td>
                                </tr>
                                <tr>
                                    <td>Date, time, IP address and browser details of your sign-up, confirmation and any changes you make</td>
                                    <td>As a record of your consent, and to spot abusive sign-ups</td>
                                </tr>
                                <tr>
                                    <td>Delivery status (e.g. bounced emails)</td>
                                    <td>To stop emailing addresses that no longer work</td>
                                </tr>
                                <tr>
                                    <td>Unsubscribe date, and a reason if you choose to give one</td>
                                    <td>To make sure we never email you again after you opt out</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p>We do <strong>not</strong> track whether you open our emails or which links you click, and we don't ask for your name or any other details.</p>

                    <h3>Double opt-in and consent</h3>
                    <p>When you sign up, we send a confirmation email. You're only added to the list after you click the link in it, so nobody can subscribe you without your agreement. Our lawful basis for sending the newsletter is your <strong>consent</strong> (UK GDPR Article 6(1)(a) and regulation 22 of the Privacy and Electronic Communications Regulations). You can withdraw your consent at any time. This doesn't affect anything we sent before you withdrew it.</p>

                    <h3>Unsubscribing</h3>
                    <p>Every newsletter email has an <strong>Unsubscribe</strong> link that removes you with one click, and supports the one-click unsubscribe button many email apps show. You can also <a href="/phplist/?p=unsubscribe&amp;id=1" class="link-text">unsubscribe here</a>, <a href="/phplist/?p=preferences&amp;id=1" class="link-text">change your details here</a>, or just email us.</p>

                    <h3>Where your data is kept and who can see it</h3>
                    <p>The newsletter runs on <a href="https://www.phplist.org" target="_blank" rel="noopener" class="link-text">phpList</a>, open-source software that we host ourselves on the same web server as this website, at <code>vatsight.com/phplist</code>. Emails are sent from our own mail server. We do not use a third-party email marketing service. Your address is never sold, rented or shared with anyone, and it's used for nothing except this newsletter. The only third party involved is our web hosting provider, which stores the server data on our behalf as a processor under a data processing agreement.</p>
                    <p>If our hosting provider stores or processes any of this data outside the UK, we make sure the transfer is covered by adequacy regulations or appropriate safeguards, as UK data protection law requires.</p>

                    <h3>How long we keep it</h3>
                    <ul>
                        <li><strong>While you're subscribed:</strong> we keep your details for as long as you stay on the list.</li>
                        <li><strong>If you never confirm:</strong> unconfirmed sign-ups are deleted regularly, normally within a month.</li>
                        <li><strong>After you unsubscribe:</strong> we keep only your email address and the date you opted out, on a suppression list, so that you are never emailed again. This is based on our legitimate interest in respecting your choice. Ask us and we'll delete it completely, but then we can't guarantee you won't be re-subscribed if someone enters your address again.</li>
                        <li><strong>If the newsletter closes:</strong> we delete the whole list.</li>
                    </ul>

                    <h2 id="cookies">4. Cookies</h2>
                    <p>The main VatSight website does not set any cookies of its own. On the <a href="/contact" class="link-text">contact page</a> only, Google reCAPTCHA sets a cookie to tell people from bots, as described in <a href="#contact-form" class="link-text">Section 2</a>; it is strictly necessary to protect the form you are choosing to use. The newsletter's sign-up, confirmation and preferences pages (under <code>vatsight.com/phplist/</code>) set a single session cookie that phpList needs to process your form. It contains no personal information and expires when you close your browser. Because it's strictly necessary for the service you've asked for, it doesn't require consent under PECR.</p>

                    <h2>5. Information the App Does NOT Collect</h2>
                    <p>Mapbox's own SDK telemetry is disabled by default (see <a href="#mapbox-sdk" class="link-text">Section 8</a>), and unless you choose to enable the optional ads described in <a href="#advertising" class="link-text">Section 9</a>, the VatSight app does not collect, transmit, or share any of the following:</p>
                    <ul>
                        <li>Your name, email address, or any contact information</li>
                        <li>Your device's location (GPS or network-based)</li>
                        <li>Device identifiers (IDFA, IDFV, or similar)</li>
                        <li>Usage analytics or behavioural telemetry</li>
                        <li>Crash reports (no third-party crash reporting SDK is integrated)</li>
                        <li>Health, financial, biometric, or sensitive personal data</li>
                        <li>Contacts, photos, microphone, or camera data</li>
                    </ul>

                    <h2>6. Information Stored On-Device Only</h2>
                    <p>VatSight stores a small amount of data locally on your device using SwiftData (Apple's encrypted, on-device database). This data never leaves your device and is never transmitted to any server.</p>

                    <div class="table-scroll">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Purpose</th>
                                    <th>Sent off-device?</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Your VATSIM CID (optional)</td>
                                    <td>Highlights your own aircraft on the map in gold</td>
                                    <td><span class="pill-no">Never</span></td>
                                </tr>
                                <tr>
                                    <td>Tracked CIDs (optional)</td>
                                    <td>Highlights aircraft belonging to friends on the map</td>
                                    <td><span class="pill-no">Never</span></td>
                                </tr>
                                <tr>
                                    <td>Last map position &amp; zoom level</td>
                                    <td>Restores your map view when you reopen the app</td>
                                    <td><span class="pill-no">Never</span></td>
                                </tr>
                                <tr>
                                    <td>App preferences (theme, refresh rate, icon sizes, layer toggles)</td>
                                    <td>Persists your display settings between sessions</td>
                                    <td><span class="pill-no">Never</span></td>
                                </tr>
                                <tr>
                                    <td>VATGlasses sector data cache</td>
                                    <td>Avoids re-downloading unchanged airspace data on each launch</td>
                                    <td><span class="pill-no">Never</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <p>If you choose to enable optional ads (see <a href="#advertising" class="link-text">Section 9</a>), the advertising SDK will make its own additional network requests while ads are enabled, in order to fetch and report on ad content.</p>

                    <p>Your VATSIM CID is a publicly visible network identifier — it is not a password or secret credential. VatSight treats it as a reference to look up publicly available data, not as personal information.</p>

                    <h2>7. Network Requests</h2>
                    <p>VatSight's own code makes outbound network requests solely to fetch publicly available data needed to power the radar. No user data is included in any of these requests. Google's ad SDK only makes requests if you turn on optional ads (see <a href="#advertising" class="link-text">Section 9</a>).</p>

                    <div class="table-scroll">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Domain</th>
                                    <th>Purpose</th>
                                    <th>User data sent?</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><code>data.vatsim.net</code></td>
                                    <td>Live VATSIM network data (pilots, controllers, ATIS). Public API with no authentication.</td>
                                    <td><span class="pill-no">None</span></td>
                                </tr>
                                <tr>
                                    <td><code>api.github.com</code></td>
                                    <td>VATGlasses airspace sector data downloaded from a public GitHub repository.</td>
                                    <td><span class="pill-no">None</span></td>
                                </tr>
                                <tr>
                                    <td><code>*.mapbox.com</code> / <code>*.mapbox.cn</code></td>
                                    <td>Map tile rendering via the Mapbox Maps iOS SDK. The SDK's optional telemetry is disabled by default in VatSight (see <a href="#mapbox-sdk" class="link-text">Section 8</a>).</td>
                                    <td><span class="pill-no">None, unless you manually<br/>re-enable Mapbox telemetry</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <h2>8. Third-Party SDKs</h2>
                    <p>VatSight uses the following third-party libraries:</p>

                    <h3 id="mapbox-sdk">Mapbox Maps iOS SDK</h3>
                    <p>Used to render the interactive map. The SDK has its own optional telemetry feature which, if active, would send a small amount of technical data to Mapbox in order to operate and improve their mapping service:</p>
                    <ul>
                        <li>IP address (retained by Mapbox for up to 30 days, then deleted)</li>
                        <li>A rotating session identifier (not linked to your identity beyond 24 hours)</li>
                        <li>Timestamps and device/OS information (user agent)</li>
                        <li>The app's bundle identifier</li>
                        <li>Basic map interaction events (e.g. map loads/views)</li>
                    </ul>
                    <p><strong>VatSight disables this telemetry by default for every user</strong> — it is switched off automatically each time the app launches, with no action required from you. If you actively choose to re-enable it during a session via the ⓘ attribution button on the map (as a way to help improve OpenStreetMap and Mapbox), it will be switched off again the next time you launch VatSight. Because VatSight never requests location access (see <a href="#location" class="link-text">Section 10</a>), this telemetry cannot include your GPS location even if enabled. VatSight does not pass your VATSIM CID, tracked CIDs, or any other identifier to Mapbox, and Mapbox states it does not sell personal data or use this telemetry for advertising. You can review Mapbox's full data practices at <a href="https://www.mapbox.com/legal/privacy" target="_blank" rel="noopener" class="link-text">mapbox.com/legal/privacy</a>.</p>
                    <p>Separately, Mapbox's SDK sends its own anonymous, non-personal "active user" ping to Mapbox regardless of the telemetry setting above — this is required by Mapbox's terms of service for billing purposes and does not carry device, session, or IP-level telemetry.</p>

                    <h3>ZIPFoundation</h3>
                    <p>An open-source Swift library used to decompress VATGlasses sector data downloaded from GitHub. It operates entirely on-device and makes no network requests.</p>

                    <h3>GEOSwift</h3>
                    <p>An open-source Swift library used for geographic polygon operations (merging airspace sectors). It operates entirely on-device and makes no network requests.</p>

                    <h2 id="advertising">9. Optional Advertising</h2>
                    <p>VatSight includes optional ads as a voluntary way to support development. Ads are <strong>off by default</strong>. You must choose to turn them on, either during onboarding or in Settings → Support VatSight, and you can turn them off again at any time. Ads never unlock or lock any feature: every feature in VatSight is free whether or not you enable ads.</p>
                    <p>Once ads are enabled, you choose which types to see, and each can be switched off on its own:</p>
                    <ul>
                        <li><strong>Settings banner:</strong> a small ad shown at the top of the Settings screen.</li>
                        <li><strong>Ads on demand:</strong> full-screen video ads that play only when you tap to watch 1, 2 or 5 of them. You can stop between ads.</li>
                        <li><strong>Ad on app launch:</strong> a full-screen ad when you open VatSight, and at most once every four hours when you return to it.</li>
                    </ul>
                    <p>Ads are served by <strong>Google AdMob</strong> (Google Ireland Limited / Google LLC). The Google Mobile Ads SDK is only started after you enable ads; if you never enable them, it makes no network requests and collects nothing. While ads are enabled, Google may collect technical data such as IP address, approximate location derived from it, device information, ad interactions, diagnostics and, only if you allow it, your device's advertising identifier (IDFA), in order to serve, measure and personalise ads and to prevent fraud. You can learn more at <a href="https://policies.google.com/technologies/partner-sites" target="_blank" rel="noopener" class="link-text">How Google uses information from sites or apps that use its services</a>.</p>
                    <p><strong>Your choices:</strong> if you are in the UK, EEA or Switzerland, Google's consent form is shown when you turn ads on, and you can change your choices later from Settings → Support VatSight → Ad Privacy Choices. Apple's App Tracking Transparency prompt is also shown when you turn ads on; if you choose "Ask App Not to Track", the IDFA is not used and ads may be less relevant. You can change this at any time in iOS Settings → Privacy &amp; Security → Tracking.</p>
                    <p>VatSight itself only stores your ad settings and a count of ads viewed, on your device. This count is never sent anywhere.</p>

                    <h2 id="location">10. Location Services</h2>
                    <p>VatSight does <strong>not</strong> request access to your device's location. The app does not use <code>CLLocationManager</code> or any GPS / network location API. The map is centred based on your previously saved map position, which is stored only on-device.</p>

                    <h2>11. iCloud Backup</h2>
                    <p>Your VatSight preferences (stored via SwiftData) may be included in iCloud backups if you have iCloud Backup enabled on your device. This is handled entirely by iOS and subject to Apple's privacy policy. The VATGlasses cache file is stored in the Documents directory and may be included in iCloud backups; it contains only public airspace data (no personal information).</p>

                    <h2>12. App Data Retention and Deletion</h2>
                    <p>All on-device data (preferences, CIDs, cache) is stored only on your device. You can delete all stored data at any time by uninstalling VatSight. The app contains no server-side user accounts, so there is no app data to delete from any server.</p>
                    <p>The VATGlasses sector data cache can also be cleared from within the app via Settings → VATGlasses Sector Data → Redownload.</p>

                    <h2>13. Children's Privacy</h2>
                    <p>VatSight is not directed at children under 13. The app's own code collects no personal information from any user, including children. The optional advertising feature described in Section 9 should only be enabled by adult users; VatSight does not knowingly direct ads at children. You must be 13 or older to subscribe to the newsletter. If you believe a child under 13 has subscribed, contact us and we'll delete their details.</p>

                    <h2>14. Security</h2>
                    <p>VatSight's on-device data is stored by SwiftData, which uses the standard iOS data protection mechanisms. All network requests use HTTPS (TLS). The app does not store or transmit any authentication credentials.</p>
                    <p>The website and newsletter pages are only served over HTTPS. Access to the newsletter's admin area is limited to the developer and protected by a strong password, and the software is kept up to date.</p>

                    <h2 id="your-rights">15. Your Rights</h2>
                    <p>Under UK data protection law, you have the right to:</p>
                    <ul>
                        <li><strong>access</strong> the personal data we hold about you and get a copy of it</li>
                        <li><strong>rectify</strong> it if it's wrong or incomplete</li>
                        <li><strong>erase</strong> it</li>
                        <li><strong>restrict</strong> or <strong>object to</strong> how we use it</li>
                        <li><strong>data portability</strong>, which means getting your data in a machine-readable format</li>
                        <li><strong>withdraw consent</strong> at any time, for example by unsubscribing from the newsletter</li>
                    </ul>
                    <p>To use any of these rights, email <a href="mailto:contact@marcelmarzec.com" class="link-text">contact@marcelmarzec.com</a>. We'll reply within one month. There's no charge.</p>
                    <p>If you're unhappy with how we've handled your data, please contact us first so we can put it right. You also have the right to complain to the UK's data protection regulator, the <a href="https://ico.org.uk/make-a-complaint/" target="_blank" rel="noopener" class="link-text">Information Commissioner's Office (ICO)</a>, on 0303 123 1113.</p>

                    <h2>16. Changes to This Policy</h2>
                    <p>If VatSight's data practices change, this policy will be updated and the "Last updated" date at the top will be revised. If a change significantly affects how we use newsletter subscribers' data, we'll also tell subscribers by email before it takes effect.</p>

                    <h2>17. Contact</h2>
                    <p>If you have any questions about this privacy policy or VatSight's data practices, please contact:</p>
                    <p><strong>Marcel Marzec</strong><br>
                    <a href="mailto:contact@marcelmarzec.com" class="link-text">contact@marcelmarzec.com</a></p>

                    <p class="doc-footnote">VatSight (the app, website and newsletter) is an independent project and is not affiliated with, endorsed by, or sponsored by VATSIM, Mapbox, VATGlasses, phpList, Formspree or Google.</p>
                </div>
            </div>
        </section>
<?php require __DIR__ . '/partials/footer.php'; ?>
